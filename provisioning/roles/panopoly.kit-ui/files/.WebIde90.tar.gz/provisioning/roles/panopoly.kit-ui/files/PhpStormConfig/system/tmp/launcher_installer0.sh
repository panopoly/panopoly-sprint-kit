#!/bin/sh
mkdir -p "/usr/local/bin"
install -g 0 -o 0 "/home/panopoly/.WebIde90/system/tmp/launcher0" "/usr/local/bin/pstorm"